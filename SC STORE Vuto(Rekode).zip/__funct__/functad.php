<?php
session_start();
require '../admin/connect.php';
define('MAX_LOGIN_ATTEMPTS', 3);
if (isset($_POST['login'])) {
  $username = $_POST["userlog"];
  $password = $_POST["userpass"];

  if (validateInput($username, $password)) {
    $username = cleanInput($username);
    $password = cleanInput($password);
    $loginAttempts = isset($_SESSION['login_attempts']) ? $_SESSION['login_attempts'] : 0;
    if ($loginAttempts >= MAX_LOGIN_ATTEMPTS) {
      sleep(2); // Menunda eksekusi selama 2 detik
      echo "<center><div style='margin-top:50px;'>Kebanyakan nyoba login jadi gini 😅</div></center>";
      exit;
    }
    $query = "SELECT * FROM data_admin WHERE user_admin = ? AND pass_admin = ?";
    $statement = $connect->prepare($query);
    $statement->bind_param("ss", $username, $password);
    $statement->execute();
    $result = $statement->get_result();
    $match = $result->num_rows;

    if ($match == 1) {
      $user = $result->fetch_assoc();
      $_SESSION['logged_ad'] = true;
      $_SESSION['username'] = $username;
      $token = generateRandomToken();
      $_SESSION['tokenad'] = $token;
      session_regenerate_id(true);
      $cookieParams = session_get_cookie_params();
      setcookie(session_name(), session_id(), 0, $cookieParams['path'], $cookieParams['domain'], true, true);
      unset($_SESSION['login_attempts']);

      $statement->close();
      header("location: index.php");
      exit;
    } else {
      $_SESSION['login_attempts'] = $loginAttempts + 1;
      echo "<center><div style='max-width:450px; margin-bottom:-18px;' class='alert alert-danger'>User atau password salah!</div></center>";
    }
    $statement->close();
  } else {
    echo "<center><div style='max-width:450px; margin-bottom:-18px;' class='alert alert-danger'>User atau password tidak valid!</div></center>";
  }
}
function validateInput($username, $password)
{
  if (strlen($username) < 10 && strlen($password) < 10) {
    return true;
  }
  return false;
}
function cleanInput($input)
{
  $input = trim($input);
  $input = stripslashes($input);
  $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
  return $input;
}
function generateRandomToken()
{
  $length = 32;
  $token = bin2hex(random_bytes($length));
  return $token;
}
