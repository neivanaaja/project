<?php
include '../admin/connect.php';
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin=" anonymous">
    <?php
    $ambil = $connect->query("SELECT * FROM data_web");
    $bagi = $ambil->fetch_assoc();
    ?>
    <meta name="Description" content="<?= $bagi['desk_web'] ?>" />
    <meta property="og:description" content="<?= $bagi['desk_web'] ?>" />
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= $bagi['webname'] ?>" />
    <link rel="shortcut icon" href="../assets/img/<?= $bagi['foto_web'] ?>" type="image/x-icon">
    <link rel="stylesheet" href="../assets/style.css">
    <link rel="stylesheet" href="../assets/new.css">
    <title><?= $bagi['webname'] ?></title>
</head>

<body>
    <div class="head">
        <a href="index.php" class="btn " id="webname"></a>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark" id="navbar">
        <div class="container">
            <button class="navbar-b b1 active-btn" data-target="konten1" style="font-size: 14px;">Product <span class="icon">&#x25BC;</span></button>
            <button class="navbar-b b2 inactive-btn" data-target="konten2" style="font-size: 14px;">Testimoni <span class="icon">&#x25BC;</span></button>
            <button class="navbar-b b3 inactive-btn" data-target="konten3" style="font-size: 14px;">Payment <span class="icon">&#x25BC;</span></button>
        </div>
    </nav>
    <div class="container konten konten1 active">
        <div class="jud">
            <h1>Semua Produk</h1>
        </div>
        <div class="row">
            <div class="main">
                <?php
                $admin = $connect->query("SELECT * FROM data_web");
                $cek = $admin->fetch_assoc();
                $no = $cek['no_admin'];
                $ambil = $connect->query("SELECT * FROM produk");
                while ($bagi = $ambil->fetch_assoc()) {;
                    $id = $bagi['id'];
                ?>
                    <div class="content">
                        <center>
                            <div class="gam" data-bs-toggle="modal" data-bs-target="#data<?= $id ?>" data-bs-whatever="@fat">
                                <img class="img" src="../assets/img/<?= $bagi['foto_pro']; ?>" alt="">
                            </div>
                        </center>
                        <div class="ord">
                            <p class=" span1"><?= $bagi['nama_pro']; ?></p>
                            <p class="span2">Rp <span><?= number_format($bagi['harga_pro']) ?></span></p>
                        </div>
                        <div class="now" data-bs-toggle="modal" data-bs-target="#data<?= $id ?>" data-bs-whatever="@fat">
                            <button type="button" class="btn">Beli Sekarang</button>
                        </div>
                    </div>
                    <div class="modal fade" id="data<?= $id ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content dark-backdrop">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <p class="p p1"><?= $bagi['nama_pro']; ?></p>
                                        <button type="button" class="btn-close p1-2" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <form id="frm1" method="post">
                                        <div class="mb-1">
                                            <div class="gam2">
                                                <img src="../assets/img/<?= $bagi['foto_pro']; ?>" alt="">
                                            </div>
                                            <center>
                                                <input style="margin-top: 10px;" type="text" id="mess" name="mail" placeholder="Email/tele/wa" class="form-control" value="">                                                                               
                                            <select id="opsi1" class="form-control" style="margin-top:-5px;border-color: #E0E3E7;margin-bottom:15px;font-size:14px" name="durasi">
                                                    <option value="" disabled selected>--Durasi Web--</option>
                                                    <option value="1 Minggu">1 Minggu (Full Garansi)</option>
                                                    <option value="1 Bulan">1 Bulan (Full Garansi)</option>
                                                </select>
                                                
                                                <select id="opsi" class="form-control" style="margin-top:-5px;border-color: #E0E3E7;margin-bottom:15px;font-size:14px" name="pay" onchange="showAdditional()">
                                                    <option value="" disabled selected>--Pembayaran--</option>
                                                    <option value="Dana">Dana</option>
                                                    <option value="Qris">Qris</option>
$options = [
  "/Qris/" => [
    "label" => "Qris",
    "image" => "assets/img/QRIS.jpeg"                                                    
                                                    <option value="Lain">Lainnya</option>
                                                </select>
                                            </center>
                                        </div>
                                        <input type="hidden" name="nama_pro" id="nama_pro" value="<?= $bagi['nama_pro']; ?>">
                                        <input type="hidden" name="link_demo" id="link_demo" value="<?= $bagi['desk_order']; ?>">
                                        <center>
                                            <button type="submit" name="beli_whatsapp" class="btn btn-success" id="wa">
                                                <i class="fa-brands fa-whatsapp"></i> Beli
                                            </button>
                                            <button type="submit" name="beli_telegram" id="demo" class="btn btn-info">
                                                Demo
                                            </button>
                                        </center>
                                    </form>
                                    <?php
                                    if (isset($_POST['beli_whatsapp']) || isset($_POST['beli_telegram'])) {
                                        $mail = $_POST['mail'];
                                        $nbar = $_POST['nbar'];
                                        $token = $_POST['token'];
                                        $pay = $_POST['pay'];
                                        $durasi = $_POST['durasi'];
                                        $subdo = $_POST['nama_link'];
                                        $nama_pro = htmlspecialchars($_POST['nama_pro']);
                                        $gambar_pro = htmlspecialchars($_POST['gambar_pro']);
                                        if (isset($_POST['beli_whatsapp'])) {
                                            $link = "https://api.whatsapp.com/send?phone=https://wa.me/6283139887149&text=Halo%20Admin%20VUTO%20%0AMau%20order%20web%20nih%0A%0A%20%2A_DETAIL%20ORDERAN_%2A%0A%0A%3E%20%2AItem%2A%20%3A%20$nama_pro%20%0A%3E%20%2AID%2FEmail%2A%20%3A%20$mail%0A%3E%20%2ADurasi%2A%20%3A%20$durasi%0A%3E%20%2APembayaran%2A%20%3A%20$pay%0A%0ASegera%20Dibuatkan%20Yaaa%21%21";
                                        } elseif (isset($_POST['beli_telegram'])) {
                                            $link = "$_POST[link_demo]";
                                        }
                                        echo "<script>location='$link'</script>";
                                    }
                                    ?>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
    <div class="container konten konten2">
        <div class="row2">
            <div class="main2">
                <?php
                $ambil = $connect->query("SELECT * FROM testimoni");
                while ($bagi = $ambil->fetch_assoc()) {;
                ?>
                    <div class="content">
                        <center>
                            <div class="gam">
                                <img class="img" src="../assets/img/<?= $bagi['foto_testi']; ?>" alt="">
                            </div>
                        </center>
                    </div>
                <?php
                }
                ?>

            </div>
        </div>
    </div>
    <div class="container konten konten3">

        <div class="row3">
            <div class="main3">
                <?php
                $ambil = $connect->query("SELECT * FROM payment");
                $bagi = $ambil->fetch_assoc();
                ?>
                <div class="content3">
                    <center>
                        <div class="head2">
                            <div class="head3">
                                <h6>List Pembayaran</h6>
                            </div>
                        </div>
                        <div class="qr1">
                            <p class="p1">Scan QRIS</p>
                            <p class="p2" id="zoom"></p>
                            <div class="gam3">
                                <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#qris" data-bs-whatever="@fat" data-lightbox="image">
                                    <img class="img3" src="../assets/img/<?= $bagi['qris']; ?>" alt="">
                                </button>
                            </div>
                        </div>

                        <div class="qr1">
                            <p class="p1">Transfer ke E-wallet / Bank</p>
                            <div class="log log1">
                                <img src="../assets/img/dana.png" alt="" class="g0">
                                <img src="../assets/img/gopay2.png" alt="" class="g0"><br>
                                <p id="wallet" onclick="copyWallet()"><?= $bagi['e_wallet']; ?></p>
                            </div>
                            <div class="log log1">
                                <img src="../assets/img/sea.png" alt="" class="g0"><br>
                                <p id="wallet" onclick="copyWallet()"><?= $bagi['s_bank']; ?></p>
                            </div>
                            <br><p class="p3">PAYMENT ATAS NAMA W****** SEMUA! SELAIN ITU CLONE! HARAP TELITI</p>
                            <p class="p3" id="zoom2"></p>
                        </div>
                    </center>
                    <!-- <center> -->
                    <div class="qr1">
                        <div class="tf">
                            <p class="p5">Setelah melakukan pembayaran mohon untuk mengirim bukti transfer berupa screenshot ke nomor whatsapp penjual</p>
                            <p class="p6">Jika sudah tunggu 5-10 mnt untuk penjual memproses pesananmu dan jangan spam agar pesanan cepat diproses!</p>
                        </div>
                    </div>
                    <!-- </center> -->
                </div>
                <div class="modal fade" id="qris" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content dark-backdrop">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <p class="p3"><span style="color: #349be5;">DANA</span> / <span style="color: #523a97;">OVO</span> / <span style="color: #00afd4;">GOPAY</span> / <span style="color: #fc0808;">LinkAja</span> / <span style="color: #ef5334;">ShopeePay</span></p>
                                    <button type="button" class="btn-close p1-2" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="gam4">
                                    <img class="img3" src="../assets/img/<?= $bagi['qris']; ?>" alt="">
                                    <center><a href="../assets/img/<?= $bagi['qris']; ?>" download class="btn btn-primary btn-sm btn-down"><i class="fa-solid fa-download" style="margin-right: 3px;"></i> Unduh Gambar</a></center>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ========= -->
    </div>
    <footer>
        <?php
        $ambil = $connect->query("SELECT * FROM data_web");
        $bagi = $ambil->fetch_assoc();
        ?>
        <div class="sos">
            <a href="<?= $bagi['linkfb']; ?>" class="i i1"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="<?= $bagi['linkwa']; ?>" class="i i2"><i class="fa-brands fa-whatsapp"></i></a>
            <a href="<?= $bagi['shortlink']; ?>" class="i i3"><i class="fa-solid fa-link"></i></a>
        </div>
        <p class="pfoot">&copy; <?= $bagi['webname'] ?></p>
    </footer>
    <script>
        // function preventRightClick(event) {
        //     event.preventDefault();
        // }

        // window.addEventListener('contextmenu', preventRightClick);

        function copyWallet() {
            var text = document.getElementById("wallet");
            var range = document.createRange();
            range.selectNode(text);
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
            document.execCommand("copy");
            window.getSelection().removeAllRanges();
            text.style.color = "green";

            setTimeout(function() {
                text.style.color = "white";
            }, 120);
        }

        function copySea() {
            var text = document.getElementById("sea");
            var range = document.createRange();
            range.selectNode(text);
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
            document.execCommand("copy");
            window.getSelection().removeAllRanges();
            text.style.color = "orange";

            setTimeout(function() {
                text.style.color = "white";
            }, 120);
        }

        function copyBc() {
            var text = document.getElementById("bc");
            var range = document.createRange();
            range.selectNode(text);
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
            document.execCommand("copy");
            window.getSelection().removeAllRanges();
            text.style.color = "#0075d5";

            setTimeout(function() {
                text.style.color = "white";
            }, 120);
        }
    </script>
    <script>
        const textElement3 = document.getElementById('zoom2');
        const text3 = "klik nomor untuk menyalin";
        const colors3 = ["white"];
        let index3 = 0;

        function getRandomColor() {
            return colors3[Math.floor(Math.random() * colors3.length)];
        }

        function displayText3() {
            if (index3 < text3.length) {
                const currentColor = getRandomColor();
                const span = document.createElement('span');
                span.textContent = text3[index3];
                span.style.color = currentColor;
                textElement3.appendChild(span);
                index3++;
                setTimeout(displayText3, 65);
            } else {
                setTimeout(resetText3, 1550);
            }
        }

        function resetText3() {
            textElement3.textContent = "";
            index3 = 0;
            displayText3();
        }

        displayText3();
    </script>
    <script>
        const textElement2 = document.getElementById('zoom');
        const text2 = "klik untuk memperbesar";
        const colors2 = ["white"];
        let index2 = 0;

        function getRandomColor() {
            return colors2[Math.floor(Math.random() * colors2.length)];
        }

        function displayText2() {
            if (index2 < text2.length) {
                const currentColor = getRandomColor();
                const span = document.createElement('span');
                span.textContent = text2[index2];
                span.style.color = currentColor;
                textElement2.appendChild(span);
                index2++;
                setTimeout(displayText2, 75);
            } else {
                setTimeout(resetText2, 1550);
            }
        }

        function resetText2() {
            textElement2.textContent = "";
            index2 = 0;
            displayText2();
        }

        displayText2();
    </script>
    <script>
        const textElement = document.getElementById('webname');
        const text = "<?= $bagi['webname']; ?>";
        const colors = ["white"];
        let index = 0;

        function getRandomColor() {
            return colors[Math.floor(Math.random() * colors.length)];
        }

        function displayText() {
            if (index < text.length) {
                const currentColor = getRandomColor();
                const span = document.createElement('span');
                span.textContent = text[index];
                span.style.color = currentColor;
                textElement.appendChild(span);
                index++;
                setTimeout(displayText, 210);
            } else {
                setTimeout(resetText, 1100);
            }
        }

        function resetText() {
            textElement.textContent = "";
            index = 0;
            displayText();
        }

        displayText();

        window.onscroll = function() {
            myFunction()
        };

        var navbar = document.getElementById("navbar");
        var sticky = navbar.offsetTop;

        function myFunction() {
            if (window.pageYOffset >= sticky) {
                navbar.classList.add("sticky");
            } else {
                navbar.classList.remove("sticky");
            }
        }
    </script>
    <script>
        const buttons = document.querySelectorAll('.navbar-b');
        const contents = document.querySelectorAll('.konten');
        const firstButton = buttons[0];
        const firstIcon = firstButton.querySelector('.icon');
        firstIcon.classList.toggle('up');

        buttons.forEach(button => {
            button.addEventListener('click', () => {
                const target = button.getAttribute('data-target');
                const targetContent = document.querySelector(`.${target}`);
                const icon = button.querySelector('.icon');
                contents.forEach(content => {
                    if (content === targetContent) {
                        content.classList.add('active');
                    } else {
                        content.classList.remove('active');
                    }
                });
                buttons.forEach(btn => {
                    const btnIcon = btn.querySelector('.icon');
                    if (btn === button) {
                        btnIcon.classList.toggle('up', targetContent.classList.contains('active'));
                    } else {
                        btnIcon.classList.remove('up');
                    }
                });
            });
        });
    </script>
    <script src="https://kit.fontawesome.com/08380760ee.js" crossorigin="anonymous"></script>
    <script src="assets/script. js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>