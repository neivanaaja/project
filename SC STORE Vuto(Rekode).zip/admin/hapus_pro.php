<?php
require './connect.php';
$ambil = $connect->query("SELECT * FROM produk WHERE id = '$_GET[idpro]'");
$pecah = $ambil->fetch_assoc();
$fotopro = $pecah['foto_pro'];
if (file_exists("../assets/img/$fotopro")) {
    unlink("../assets/img/$fotopro");
}

$query = "DELETE FROM produk WHERE id = $_GET[idpro]";
$result = mysqli_query($connect, $query);
if ($result) {
    echo "<script>location='index.php?prod=';</script>";
}
