<?php
$ambil = $connect->query("SELECT * FROM testimoni");
$bagi = $ambil->fetch_assoc();
?>

<form method="post" enctype="multipart/form-data">
   <div class="mb-1">
      <label style="padding: 3px 8px 3px 8px;margin-top:10px" class="custom-file-label" id="fileLabel">
         Foto Testimoni
         <input type="file" name="fototesti" class="form-control">
      </label>
   </div>
   <div class="modal-footer" style="margin-top: 20px;">
      <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
      <button type="submit" name="tambah3" class="btn btn-primary btn-sm">Tambah</button>
   </div>
   <?php
   if (isset($_POST['tambah3'])) {
      $nama = $_FILES['fototesti']['name'];
      $lokasi = $_FILES['fototesti']['tmp_name'];
      move_uploaded_file($lokasi, "../assets/img/" . $nama);
      $connect->query("INSERT INTO testimoni (foto_testi) 
        VALUES('$nama')");
      echo "<meta http-equiv='refresh' content='0;url=index.php?testi='>";
   }
   ?>
</form>