<?php
session_start();
require '../admin/connect.php';
if (!isset($_SESSION['logged_ad']) || $_SESSION['logged_ad'] !== true || !isset($_SESSION['tokenad']) || isset($_SESSION['login_attempts'])) {
  header("location: login.php");
  exit;
} else {
?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../assets/x.css">
    <?php
    $ambil = $connect->query("SELECT * FROM data_web");
    $bagi = $ambil->fetch_assoc();
    ?>
    <link rel="shortcut icon" href="../assets/img/<?= $bagi['foto_web'] ?>" type="image/x-icon">
    <title>Panel <?= $bagi['webname'] ?></title>
  </head>

  <body>
    <div class="container">
      <div class="row-start">
        <div class="main">
          <center>
            <h5 class="j1">Panel <?= $bagi['webname'] ?></h5>
          </center>
        </div>
      </div>
      <div class="row">
        <div class="main">
          <div class="row">
            <div class="main">
              <div style="margin-bottom: -5px;" class="head">
                <div style="float: left;margin-bottom: -5px;" class="img">
                  <?php
                  $ambil = $connect->query("SELECT * FROM data_web");
                  $bagi = $ambil->fetch_assoc();
                  ?>
                  <img src="../assets/img/<?= $bagi['foto_web'] ?>" style="width: 100px; height:auto;" alt="">
                </div>
                <div style="float: right;margin-bottom: -5px;" class="img">
                  <?php
                  $ambil = $connect->query("SELECT * FROM payment");
                  $bagi = $ambil->fetch_assoc();
                  ?>
                  <img src="../assets/img/<?= $bagi['qris'] ?>" style="width: 100px; height:auto;" alt="">
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="main">
              <div style="margin-bottom: -5px;" class="head">
                <?php
                $ambil = $connect->query("SELECT * FROM data_admin");
                $bagi = $ambil->fetch_assoc();
                ?>
                <span style="margin-bottom: 3px;margin-bottom: -2px;font-size:14px;">User: <span style="color: #8364ff;"><?= $bagi['user_admin'] ?> </span> | Pass: <span style="color: #8364ff;"><?= $bagi['pass_admin'] ?></span>
                  <button style="float: right; margin-bottom:-5px;background-color: #3d50d8; border: 1px solid #3d50d8;" type="button" class="btn btn-primary btn-sm btn-ad" data-bs-toggle="modal" data-bs-target="#adm" data-bs-whatever="@fat">Edit</button>
                </span>
              </div>
              <div class="modal fade" id="adm" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content dark-backdrop">
                    <div style="margin-bottom: -10px;" class="modal-header">
                      <h5 style="margin-bottom: -10px;" class="modal-title" id="exampleModalLabel">Login Admin</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST">
                      <div class="modal-body">
                        <?php
                        $ambil = $connect->query("SELECT * FROM data_admin");
                        $bagi = $ambil->fetch_assoc();
                        ?>
                        <div class="mb-1">
                          <label class="col-form-label">User Admin</label>
                          <input type="text" name="upl" class="form-control" value="<?= $bagi['user_admin']; ?>">
                        </div>
                        <div class="mb-1">
                          <label class="col-form-label">Password Admin</label>
                          <input type="text" name="ppl" class="form-control" value="<?= $bagi['pass_admin']; ?>">
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="adm" class="btn btn-primary btn-sm">Ubah</button>
                      </div>
                    </form>
                    <?php
                    if (isset($_POST['adm'])) {
                      $query = "UPDATE data_admin SET user_admin = '$_POST[upl]', pass_admin = '$_POST[ppl]' WHERE id";
                      $add =  mysqli_query($connect, $query);
                      if ($add) {
                        echo "<script>location='index.php';</script>";
                      }
                    }
                    ?>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div id="status" class="table-responsive">
            <table style="margin-bottom: 15px;">
              <?php
              $ambil = $connect->query("SELECT * FROM payment");
              $bagi = $ambil->fetch_assoc();
              ?>
              <tr>
                <td style="padding-right: 15px; padding-bottom: 5px;">E-Wallet</td>
                <td style="padding-right: 15px; padding-bottom: 5px;">Sea Bank</td>
              </tr>
              <tr>
                <td style="padding-right: 15px; color: rgb(14, 172, 196);" id="domain"><?= $bagi['e_wallet'] ?></td>
                <td style="padding-right: 15px; color: rgb(14, 172, 196);" id="idzone"><?= $bagi['s_bank'] ?></td>
              </tr>
              <tr>
                <td style="padding-top: 10px;"></td>
              </tr>
              <tr>
                <td style="padding-right: 15px; padding-bottom: 5px;">Bank BCA</td>
                <td style="padding-right: 15px; padding-bottom: 5px;">No. Admin</td>
              </tr>
              <tr>
                <td style="padding-right: 15px; color: rgb(14, 172, 196);"><?= $bagi['bca_bank'] ?></td>
                <?php
                $ambil = $connect->query("SELECT * FROM data_web");
                $bagi = $ambil->fetch_assoc();
                ?>
                <td style="padding-right: 15px; color: rgb(14, 172, 196);"><?= $bagi['no_admin'] ?></td>
              </tr>
            </table>
          </div>

          <center>
            <button type="button" class="btn btn-outline-primary btn-sm btn-eda" data-bs-toggle="modal" data-bs-target="#data" data-bs-whatever="@fat">
              Data Payment
            </button>
            <button type="button" class="btn btn-outline-primary btn-sm btn-eda2" data-bs-toggle="modal" data-bs-target="#data2" data-bs-whatever="@fat">
              Data Web
            </button>
          </center>

          <div class="modal fade" id="data" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content dark-backdrop">
                <div style="margin-bottom: -10px;" class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Ubah Data</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <form method="post" enctype="multipart/form-data">
                    <?php
                    $ambil = $connect->query("SELECT * FROM payment WHERE id");
                    $pecah = $ambil->fetch_assoc();
                    ?>
                    <div class="mb-1">
                      <label class="col-form-label">QRIS</label><br>
                      <img style="margin-bottom: 10px; width: 60px;height:auto;" src="../assets/img/<?= $pecah['qris'] ?>" width="100">
                      <br>
                      <label style="padding: 3px 8px 3px 8px;" class="custom-file-label" id="fileLabel">
                        Pilih File
                        <input type="file" name="foto1" class="form-control file" onchange="updateFileName(this)">
                      </label>
                      <span id="selectedFileName"></span>
                    </div>
                    <div class="mb-1">
                      <label class="col-form-label">E-Wallet</label>
                      <input type="text" name="wallet" class="form-control" value="<?= $pecah['e_wallet']; ?>">
                    </div>
                    <div class="mb-1">
                      <label class="col-form-label">Sea Bank</label>
                      <input type="text" name="sbank" class="form-control" value="<?= $pecah['s_bank']; ?>">
                    </div>
                    <div class="mb-1">
                      <label class="col-form-label">Bank BCA</label>
                      <input type="text" name="bca" class="form-control" value="<?= $pecah['bca_bank']; ?>">
                    </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                  <button type="submit" name="ubah2" class="btn btn-primary btn-sm">Ubah</button>
                </div>
                </form>
                <?php
                if (isset($_POST['ubah2'])) {
                  $namafoto = $_FILES['foto1']['name'];
                  $lokasifoto = $_FILES['foto1']['tmp_name'];
                  // $id = $_POST['id'];
                  if (!empty($lokasifoto)) {
                    move_uploaded_file($lokasifoto, "../assets/img/$namafoto");
                    $connect->query("UPDATE payment SET qris = '$namafoto', e_wallet = '$_POST[wallet]',  s_bank = '$_POST[sbank]', bca_bank = '$_POST[bca]' WHERE id");
                  } else {
                    $connect->query("UPDATE payment SET e_wallet = '$_POST[wallet]', s_bank = '$_POST[sbank]', bca_bank = '$_POST[bca]' WHERE id");
                  }
                  echo "<script>location='index.php';</script>";
                }
                ?>
              </div>
            </div>
          </div>
          <!-- === -->
          <div class="modal fade" id="data2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content dark-backdrop">
                <div style="margin-bottom: -10px;" class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Ubah Data Tools</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </button>
                </div>
                <div class="modal-body">
                  <form method="post" enctype="multipart/form-data">
                    <?php
                    $ambil = $connect->query("SELECT * FROM data_web WHERE id");
                    $pecah = $ambil->fetch_assoc();
                    ?>
                    <div class="mb-1">
                      <label class="col-form-label">Logo Web</label><br>
                      <img style="margin-bottom: 10px; width: 60px;height:auto;" src="../assets/img/<?= $pecah['foto_web'] ?>" width="100">
                      <br>
                      <label style="padding: 3px 8px 3px 8px;" class="custom-file-label" id="fileLabel">
                        Pilih File
                        <input type="file" name="foto" class="form-control file" onchange="updateFileName(this)">
                      </label>
                      <span id="selectedFileName"></span>
                    </div>
                    <div class="mb-1">
                      <label class="col-form-label">Nama Web</label>
                      <input type="text" name="nama" class="form-control" value="<?= $pecah['webname']; ?>">
                    </div>
                    <div class="mb-1">
                      <label class="col-form-label">Deskripsi Web</label>
                      <input type="text" name="desk_web" class="form-control" value="<?= $pecah['desk_web']; ?>">
                    </div>
                    <div class="mb-1">
                      <label class="col-form-label">No. WhatsApp (wajib pakai +62)</label>
                      <input type="text" name="no_admin" class="form-control" value="<?= $pecah['no_admin']; ?>">
                    </div>
                    <div class="mb-1">
                      <label class="col-form-label">Link Media Sosial</label>
                      <input type="text" style="margin-bottom: 5px;" name="linkfb" class="form-control" value="<?= $pecah['linkfb']; ?>" placeholder="link facebook">
                      <input type="text" style="margin-bottom: 5px;" name="linkwa" class="form-control" value="<?= $pecah['linkwa']; ?>" placeholder="link whatsapp">
                      <input type="text" name="shortlink" class="form-control" value="<?= $pecah['shortlink']; ?>" placeholder="link short">
                    </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                  <button type="submit" name="ubah22" class="btn btn-primary btn-sm">Ubah</button>
                </div>
                </form>
                <?php
                if (isset($_POST['ubah22'])) {
                  $namafoto = $_FILES['foto']['name'];
                  $lokasifoto = $_FILES['foto']['tmp_name'];
                  $id = $_POST['id'];
                  if (!empty($lokasifoto)) {
                    move_uploaded_file($lokasifoto, "../assets/img/$namafoto");
                    $connect->query("UPDATE data_web SET webname = '$_POST[nama]', foto_web = '$namafoto', linkfb = '$_POST[linkfb]', linkwa = '$_POST[linkwa]', shortlink = '$_POST[shortlink]', desk_web = '$_POST[desk_web]', no_admin = '$_POST[no_admin]' WHERE id");
                  } else {
                    $connect->query("UPDATE data_web SET webname = '$_POST[nama]', linkfb = '$_POST[linkfb]', linkwa = '$_POST[linkwa]', shortlink = '$_POST[shortlink]', desk_web = '$_POST[desk_web]', no_admin = '$_POST[no_admin]' WHERE id");
                  }
                  echo "<script>location='index.php';</script>";
                }
                ?>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="main">
          <form class="form" action="" method="GET">
            <button type="submit" class="btn btn-primary btn-sm btn1" name="prod">Data Produk</button>
            <button class="btn btn-primary btn-sm btn2" type="submit" name="testi">Data Testimoni</button>
          </form>
        </div>
        </form>
      </div>
      <?php if (isset($_GET['prod'])) { ?>
        <div class="row">
          <div class="main">
            <div class="table-responsive">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Link Demo</th>
                    <th>Foto</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $no = 1;
                  $ambil = $connect->query("SELECT * FROM produk WHERE id");
                  while ($bagi = $ambil->fetch_assoc()) {;
                    $id = $bagi['id'];
                  ?>
                    <tr>
                      <td><?= $no ?></td>
                      <td><?= $bagi['nama_pro'] ?></td>
                      <td><?= number_format($bagi['harga_pro']) ?></td>
                      <td><?= $bagi['desk_order'] ?></td>
                      <td>
                        <img src="../assets/img/<?= $bagi['foto_pro'] ?>" style="width: 50px; height:auto">
                      </td>
                      <td>
                        <center>
                          <form method="get">
                            <button type="submit" name="ubah11" value="<?= $id ?>" class="btn btn-info btn-sm" style="color:white">
                              Ubah
                            </button>
                          </form>
                          <div style=" margin-top: 4px;"><a href="hapus_pro.php?idpro=<?= $bagi['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus tampilan?')">Hapus</a>
                          </div>
                        </center>
                      </td>
                    </tr>
                </tbody>
              <?php
                    $no++;
                  }
              ?>
              </table>
            </div>
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#prod" data-bs-whatever="@fat">
              Tambah Tampilan
            </button>
            <div class="modal fade" id="prod" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content dark-backdrop">
                  <div style="margin-bottom: -10px;" class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Tampilan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </button>
                  </div>
                  <div class="modal-body">
                    <?php include_once 'tambahtamp.php'
                    ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php } ?>

      <?php if (isset($_GET['ubah11'])) { ?>
        <div class="row">
          <div class="main">
            <?php
            $id2 = $_GET['ubah11'];
            $ambil = $connect->query("SELECT * FROM produk WHERE id = $id2");
            $bagi = $ambil->fetch_assoc();
            $harga = $bagi['harga_pro'];
            ?>
            <form action="" method="post" enctype="multipart/form-data">
              <div class="mb-1">
                <label class="col-form-label">Nama</label>
                <input type="text" name="nama" class="form-control" value="<?= $bagi['nama_pro'] ?>" style="background-color: rgb(46, 46, 46); color:white;font-size:13px;">
              </div>
              <div class=" mb-1">
                <label class="col-form-label">Harga</label>
                <input type="number" name="harga" class="form-control" value="<?= $harga ?>" style="background-color: rgb(46, 46, 46); color:white;font-size:13px;">
              </div>
              <div class=" mb-1">
                <label class="col-form-label">Link Demo</label>
                <input type="text" name="desk_order" class="form-control" value="<?= $bagi['desk_order'] ?>" style="background-color: rgb(46, 46, 46); color:white;font-size:13px;">
              </div>
              <div class="mb-1">
                <label style="margin-top:10px" for="">Ubah Foto</label><br>
                <img style="margin-bottom: 10px; width:80px;height:auto;margin-top:10px" src="../assets/img/<?= $bagi['foto_pro'] ?>">
                <input type="file" name="foto5" class="form-control file">
                </label>
              </div>
              <div class="modal-footer" style="margin-top: 20px; margin-bottom:-10px">
                <a href="index.php?prod=" type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</a>
                <button type="submit" name="ubah8" class="btn btn-primary btn-sm">Ubah</button>
              </div>
            </form>
            <?php
            if (isset($_POST['ubah8'])) {
              $namafoto = $_FILES['foto5']['name'];
              $lokasifoto = $_FILES['foto5']['tmp_name'];
              if (!empty($lokasifoto)) {
                move_uploaded_file($lokasifoto, "../assets/img/$namafoto");
                $connect->query("UPDATE produk SET nama_pro = '$_POST[nama]', harga_pro='$_POST[harga]', desk_order='$_POST[desk_order]', foto_pro='$namafoto' WHERE id = $id2");
              } else {
                $connect->query("UPDATE produk SET nama_pro = '$_POST[nama]', harga_pro='$_POST[harga]', desk_order='$_POST[desk_order]' WHERE id = $id2");
              }

              echo "<script>location='index.php?prod=';</script>";
            }
            ?>
          </div>
        </div>
      <?php } ?>


      <?php if (isset($_GET['testi'])) { ?>
        <div class="row">
          <div class="main">
            <div class="table-responsive">
              <table style="width: 100%; height:auto;">
                <thead>
                  <tr>
                    <th style="padding-right: 10px;">No</th>
                    <th style="padding-right: 10px;">Foto</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $no = 1;
                  $ambil = $connect->query("SELECT * FROM testimoni WHERE id");
                  while ($bagi = $ambil->fetch_assoc()) {;
                    $id = $bagi['id'];
                  ?>
                    <tr>
                      <td><?= $no ?></td>
                      <td>
                        <img src="../assets/img/<?= $bagi['foto_testi'] ?>" style="width: 80px; height:auto; margin-top:10px">
                      </td>
                      <td>
                        <div style=" margin-top: 4px;"><a href="hapus_testi.php?id=<?= $bagi['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus testi?')">Hapus</a>
                        </div>
                      </td>
                    </tr>
                </tbody>
              <?php
                    $no++;
                  }
              ?>
              </table>
            </div>
            <button type="button" style="margin-top: 20px;" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#testi" data-bs-whatever="@fat">
              Tambah Testimoni
            </button>
            <div class="modal fade" id="testi" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content dark-backdrop">
                  <div style="margin-bottom: -10px;" class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Testi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </button>
                  </div>
                  <div class="modal-body">
                    <?php include_once 'tambahtesti.php'
                    ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php } ?>

      <div class="row-end">
        <div class="main">
          <?php
          $ambil = $connect->query("SELECT * FROM data_web");
          $bagi = $ambil->fetch_assoc();
          ?>
          <center>
            <p class="j2">&copy; <?= $bagi['webname'] ?></p>
          </center>
        </div>
      </div>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>

  </html>
<?php
}
mysqli_close($connect);
?>