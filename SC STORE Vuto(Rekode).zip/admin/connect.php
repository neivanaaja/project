<?php
// localhost:3306
$host = "localhost";
$username = "root";
$password = "";
$database = "store";

if (!filter_var($host, FILTER_VALIDATE_IP) && !filter_var($host, FILTER_VALIDATE_DOMAIN)) {
    die("Invalid host");
}
if (empty($username)) {
    die("Username is required");
}
// if (empty($password)) {
//     die("Password is required");
// }
if (empty($database)) {
    die("Database name is required");
}
$connect = mysqli_connect($host, $username, $password, $database);
