<?php
require './connect.php';
$ambil = $connect->query("SELECT * FROM testimoni WHERE id = '$_GET[id]'");
$pecah = $ambil->fetch_assoc();
$fototesti = $pecah['foto_testi'];
if (file_exists("../assets/img/$fototesti")) {
    unlink("../assets/img/$fototesti");
}

$query = "DELETE FROM testimoni WHERE id = $_GET[id]";
$result = mysqli_query($connect, $query);
if ($result) {
    echo "<script>location='index.php?testi=';</script>";
}
