<?php
$ambil = $connect->query("SELECT * FROM produk");
$bagi = $ambil->fetch_assoc();
?>

<form method="post" enctype="multipart/form-data">
   <div class="mb-1">
      <label class="col-form-label">Nama</label>
      <input type="text" name="nama" class="form-control">
   </div>
   <div class="mb-1">
      <label class="col-form-label">Harga</label>
      <input type="number" name="harga" class="form-control">
   </div>
   <div class="mb-1">
      <label class="col-form-label">Link Demo</label>
      <input type="text" name="desk_order" class="form-control">
   </div>
   <div class="mb-1">
      <label style="padding: 3px 8px 3px 8px;margin-top:10px" class="custom-file-label" id="fileLabel">
         Foto Produk
         <input type="file" name="foto3" class="form-control file">
      </label>
   </div>
   <div class="modal-footer" style="margin-top: 20px;">
      <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
      <button type="submit" name="tambah3" class="btn btn-primary btn-sm">Tambah</button>
   </div>
   <?php
   if (isset($_POST['tambah3'])) {
      $nama = $_FILES['foto3']['name'];
      $lokasi = $_FILES['foto3']['tmp_name'];
      move_uploaded_file($lokasi, "../assets/img/" . $nama);
      $connect->query("INSERT INTO produk (nama_pro, harga_pro, desk_order, foto_pro) 
        VALUES('$_POST[nama]','$_POST[harga]','$_POST[desk_order]','$nama')");
      echo "<meta http-equiv='refresh' content='0;url=index.php?prod='>";
   }
   ?>
</form>