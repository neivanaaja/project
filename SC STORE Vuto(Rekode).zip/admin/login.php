<?php
require '../__funct__/functad.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="../assets/log.css">
  <?php
  // $ambil = $connect->query("SELECT * FROM statusn");
  // $bagi = $ambil->fetch_assoc();
  ?>
  <!-- <link rel="shortcut icon" href="../assets/img/<?= $bagi['logoshort'] ?>" type="image/x-icon"> -->
  <title>Login Admin</title>
  <style>
    .container .row footer {
      margin-top: 40px;
      margin-bottom: 15px;
    }

    .container .row footer .btn {
      border-radius: 5px;
      font-size: 12px;
    }

    .container .row footer .btn-2 {
      background-color: rgb(0, 214, 0);
      border-color: rgb(0, 214, 0);
    }
  </style>
</head>

<body>
  <div class="container cont1">
    <div class="row row1">
      <div class="head">
        <?php
        $ambil = $connect->query("SELECT * FROM data_web");
        $bagi = $ambil->fetch_assoc();
        ?>
        <center>
          <img src="../assets/img/<?= $bagi['foto_web'] ?>" alt="">
          <h3>Login Admin</h3>
        </center>
      </div>
      <form method="POST" action="">
        <div class="mb-3">
          <input style="margin-bottom: -8px;" class="form-control" type="text" autofocus name="userlog" placeholder="User" required="required" />
        </div>
        <div class="mb-3">
          <input class="form-control" type="password" autofocus name="userpass" placeholder="Password" required="required" />
        </div>
        <div class="button">
          <button class="btn btn-primary btn1" name="login" type="submit">Login</button>
          <a href="../index.php" class="btn btn-outline-warning btn2">Kembali</a>
        </div>
      </form>
      <footer>

      </footer>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>